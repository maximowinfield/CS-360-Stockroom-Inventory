package com.example.stockroom;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;

/** Sends once when a saved item first reaches zero; rendering never sends messages. */
public final class SmsAlerts {
    private SmsAlerts() { }
    public static boolean shouldAlert(InventoryItem before, InventoryItem after) {
        return after != null && after.quantity == 0 && (before == null || before.quantity > 0);
    }
    public static void afterSave(Context context, long userId, InventoryItem before, InventoryItem after) {
        if (!shouldAlert(before, after) || ContextCompat.checkSelfPermission(context,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return;
        if (!context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) return;
        String phone = InventoryDatabase.get(context).smsPhone(userId, true);
        if (phone.isEmpty()) return;
        try {
            SmsManager manager = context.getSystemService(SmsManager.class);
            if (manager == null) throw new IllegalStateException("SMS unavailable");
            String message = "Stockroom: " + after.name + " (" + after.sku
                    + ") is out of stock. Location: " + after.location + ".";
            ArrayList<String> parts = manager.divideMessage(message);
            ArrayList<PendingIntent> sent = new ArrayList<>();
            for (int index = 0; index < parts.size(); index++) {
                Intent result = new Intent(context, SmsResultReceiver.class)
                        .setAction("com.example.stockroom.SMS_SENT")
                        .setData(android.net.Uri.parse("stockroom://sms/" + System.nanoTime() + "/" + index));
                sent.add(PendingIntent.getBroadcast(context, 0, result,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_ONE_SHOT));
            }
            manager.sendMultipartTextMessage(phone, null, parts, sent, null);
            Toast.makeText(context, R.string.sms_queued, Toast.LENGTH_LONG).show();
        } catch (RuntimeException exception) {
            // A missing SIM, revoked permission, or carrier failure must never undo inventory.
            Toast.makeText(context, R.string.sms_failed, Toast.LENGTH_LONG).show();
        }
    }
}

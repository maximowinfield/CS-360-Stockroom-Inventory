package com.example.stockroom;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

/** Connects the existing XML screens to persistent inventory operations. */
public class ScreenFragment extends Fragment {
    private String screen;
    private int itemIndex;
    private InventoryDatabase database() { return host().database(); }
    private void message(String text) { Snackbar.make(requireView(), text, Snackbar.LENGTH_LONG).show(); }

    public static ScreenFragment create(String screen, int item) {
        ScreenFragment fragment = new ScreenFragment();
        Bundle arguments = new Bundle();
        arguments.putString("screen", screen);
        arguments.putInt("item", item);
        fragment.setArguments(arguments);
        return fragment;
    }

    private MainActivity host() { return (MainActivity) requireActivity(); }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        screen = requireArguments().getString("screen", "login");
        itemIndex = requireArguments().getInt("item", 0);
        int layout;
        switch (screen) {
            case "inventory": layout = R.layout.fragment_inventory; break;
            case "form": case "edit": layout = R.layout.fragment_item_form; break;
            case "detail": layout = R.layout.fragment_item_detail; break;
            case "notifications": layout = R.layout.fragment_notifications; break;
            default: layout = R.layout.fragment_login;
        }
        return inflater.inflate(layout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        if (toolbar != null) toolbar.setNavigationOnClickListener(
                v -> requireActivity().getOnBackPressedDispatcher().onBackPressed());
        switch (screen) {
            case "inventory": setupInventory(view, toolbar); break;
            case "form": case "edit": setupForm(view, toolbar); break;
            case "detail": setupDetail(view); break;
            case "notifications":
                setupNotifications(view);
                break;
            default:
                view.findViewById(R.id.loginButton).setOnClickListener(v -> authenticate(view, false));
                view.findViewById(R.id.createAccountButton).setOnClickListener(v -> authenticate(view, true));
        }
    }

    private void setupInventory(View view, MaterialToolbar toolbar) {
        toolbar.getMenu().add(0, 1, 0, R.string.alerts).setIcon(R.drawable.ic_sms)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        toolbar.getMenu().add(0, 2, 1, R.string.logout).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        toolbar.setOnMenuItemClickListener(menuItem -> {
            if (menuItem.getItemId() == 1) host().showScreen("notifications", 0, true);
            else host().logOut();
            return true;
        });
        RecyclerView grid = view.findViewById(R.id.inventoryGrid);
        int width = getResources().getConfiguration().screenWidthDp;
        if (getResources().getConfiguration().screenHeightDp < 600) {
            view.findViewById(R.id.inventoryHeader).setVisibility(View.GONE);
            toolbar.setTitle(R.string.inventory_heading);
        }
        float fontScale = getResources().getConfiguration().fontScale;
        int columns = width >= 600 ? 3 : width >= 360 && fontScale <= 1.25f ? 2 : 1;
        grid.setLayoutManager(new GridLayoutManager(requireContext(), columns));
        java.util.List<InventoryItem> items = database().items();
        int empty = 0;
        for (InventoryItem item : items) if (item.quantity == 0) empty++;
        ((TextView) view.findViewById(R.id.inventorySummary)).setText(
                getString(R.string.inventory_count, items.size(), empty));
        InventoryAdapter adapter = new InventoryAdapter(items,
                index -> host().showScreen("detail", index, true), this::confirmDelete);
        grid.setAdapter(adapter);
        EditText search = view.findViewById(R.id.search);
        Chip outOfStock = view.findViewById(R.id.outOfStockChip);
        Runnable filter = () -> {
            adapter.filter(search.getText().toString(), outOfStock.isChecked());
            view.findViewById(R.id.emptyState).setVisibility(
                    adapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
        };
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter.run(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        outOfStock.setOnCheckedChangeListener((button, checked) -> filter.run());
        filter.run();
        view.findViewById(R.id.addItemButton).setOnClickListener(v -> host().showScreen("form", 0, true));
    }

    private void setupForm(View view, MaterialToolbar toolbar) {
        if ("edit".equals(screen)) {
            InventoryItem item = database().item(itemIndex);
            if (item == null) { host().showInventory(); return; }
            toolbar.setTitle(R.string.editItemButton);
            ((TextView) view.findViewById(R.id.formHeading)).setText(R.string.edit_heading);
            ((TextView) view.findViewById(R.id.formHelp)).setText(R.string.edit_help);
            ((EditText) view.findViewById(R.id.productName)).setText(item.name);
            ((EditText) view.findViewById(R.id.productSku)).setText(item.sku);
            ((EditText) view.findViewById(R.id.productLocation)).setText(item.location);
            ((EditText) view.findViewById(R.id.productQuantity)).setText(String.valueOf(item.quantity));

        }
        view.findViewById(R.id.saveItemButton).setOnClickListener(v -> saveForm(view));
        view.findViewById(R.id.cancelItemButton).setOnClickListener(
                v -> requireActivity().getOnBackPressedDispatcher().onBackPressed());
    }

    private void setupDetail(View view) {
        InventoryItem item = database().item(itemIndex);
        if (item == null) { view.post(() -> host().showInventory()); return; }
        ((TextView) view.findViewById(R.id.detailName)).setText(item.name);
        ((TextView) view.findViewById(R.id.detailSku)).setText(item.sku);
        ((TextView) view.findViewById(R.id.detailLocation)).setText(
                getString(R.string.location_format, item.location));
        ((TextView) view.findViewById(R.id.detailQuantity)).setText(String.valueOf(item.quantity));
        view.findViewById(R.id.decreaseButton).setEnabled(item.quantity > 0);
        view.findViewById(R.id.increaseButton).setOnClickListener(v -> adjustQuantity(1));
        view.findViewById(R.id.decreaseButton).setOnClickListener(v -> adjustQuantity(-1));
        view.findViewById(R.id.applyAdjustment).setOnClickListener(v -> {
            try { adjustQuantity(Integer.parseInt(value(view, R.id.quantityAdjustment))); }
            catch (NumberFormatException exception) { message("Enter a whole-number adjustment."); }
        });
        view.findViewById(R.id.editItemButton).setOnClickListener(
                v -> host().showScreen("edit", itemIndex, true));
        view.findViewById(R.id.deleteDetailButton).setOnClickListener(v -> confirmDelete(itemIndex));
    }

    private void confirmDelete(int index) {
        InventoryItem item = database().item(index);
        if (item == null) { host().showInventory(); return; }
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(getString(R.string.delete_title, item.name))
                .setMessage(R.string.delete_message)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete_confirm, (dialog, which) -> {
                    try { database().deleteItem(index); host().showInventory(); }
                    catch (android.database.SQLException exception) { message("Unable to delete. Please try again."); }
                }).show();
    }

    private String value(View view, int id) {
        return ((EditText) view.findViewById(id)).getText().toString().trim();
    }

    private void authenticate(View view, boolean create) {
        String username = value(view, R.id.username);
        char[] password = ((EditText) view.findViewById(R.id.password)).getText().toString().toCharArray();
        TextView error = view.findViewById(R.id.loginError);
        if (username.isEmpty() || username.length() > 50 || password.length == 0
                || password.length > 128 || (create && password.length < 8)) {
            error.setText("Use a username of 1–50 characters and a password of 8–128 characters for a new account.");
            error.setVisibility(View.VISIBLE);
            java.util.Arrays.fill(password, '\0');
            return;
        }
        error.setVisibility(View.GONE);
        view.findViewById(R.id.loginButton).setEnabled(false);
        view.findViewById(R.id.createAccountButton).setEnabled(false);
        view.findViewById(R.id.loginProgress).setVisibility(View.VISIBLE);
        MainActivity activity = host();
        InventoryDatabase db = database();
        // Password derivation is deliberately expensive, so it runs off the UI thread.
        new Thread(() -> {
            long result = -1;
            String failure = "Username or password is incorrect.";
            try { result = create ? db.createUser(username, password) : db.authenticate(username, password); }
            catch (android.database.sqlite.SQLiteConstraintException exception) { failure = "That username already exists. Choose another or log in."; }
            catch (RuntimeException exception) { failure = "Unable to access the account. Please try again."; }
            finally { java.util.Arrays.fill(password, '\0'); }
            final long userId = result;
            final String feedback = failure;
            activity.runOnUiThread(() -> {
                // A rotated or replaced screen must not receive a stale login callback.
                if (!isAdded() || getView() != view || activity.isDestroyed()) return;
                view.findViewById(R.id.loginButton).setEnabled(true);
                view.findViewById(R.id.createAccountButton).setEnabled(true);
                view.findViewById(R.id.loginProgress).setVisibility(View.GONE);
                if (userId > 0 && !activity.getSupportFragmentManager().isStateSaved()) {
                    ((EditText) view.findViewById(R.id.password)).setText("");
                    activity.signIn(userId);
                } else {
                    error.setText(userId > 0 ? "Account verified. Log in to continue." : feedback);
                    error.setVisibility(View.VISIBLE);
                }
            });
        }, "stockroom-login").start();
    }

    private void saveForm(View view) {
        try {
            int quantity = Integer.parseInt(value(view, R.id.productQuantity));
            int id = "edit".equals(screen) ? itemIndex : 0;
            InventoryItem before = id == 0 ? null : database().item(id);
            int saved = database().saveItem(id, value(view, R.id.productName),
                    value(view, R.id.productSku), value(view, R.id.productLocation), quantity);
            SmsAlerts.afterSave(requireContext(), host().userId(), before, database().item(saved));
            host().showInventory();
        } catch (NumberFormatException exception) { message("Quantity must be a whole number from 0 to 2147483647."); }
        catch (android.database.sqlite.SQLiteConstraintException exception) { message("That SKU already exists. Use a unique SKU."); }
        catch (IllegalArgumentException | IllegalStateException exception) { message(exception.getMessage()); }
        catch (android.database.SQLException exception) { message("Unable to save. Please try again."); }
    }

    private void adjustQuantity(int adjustment) {
        try {
            InventoryItem before = database().item(itemIndex);
            if (before == null) { host().showInventory(); return; }
            long next = (long) before.quantity + adjustment;
            if (next < 0 || next > Integer.MAX_VALUE) { message("Quantity must stay between 0 and 2147483647."); return; }
            database().saveItem(before.id, before.name, before.sku, before.location, (int) next);
            SmsAlerts.afterSave(requireContext(), host().userId(), before, database().item(before.id));
            ((EditText) requireView().findViewById(R.id.quantityAdjustment)).setText("");
            setupDetail(requireView());
        } catch (RuntimeException exception) { message("Unable to adjust stock. Please try again."); }
    }

    private void setupNotifications(View view) {
        EditText phone = view.findViewById(R.id.smsPhone);
        phone.setText(database().smsPhone(host().userId(), false));
        com.google.android.material.switchmaterial.SwitchMaterial enabled = view.findViewById(R.id.smsOptIn);
        enabled.setChecked(!database().smsPhone(host().userId(), true).isEmpty());
        view.findViewById(R.id.enableSmsButton).setOnClickListener(v -> {
            if (saveSmsPreferences(view)) host().requestSmsPermission();
        });
        view.findViewById(R.id.saveSmsButton).setOnClickListener(v -> {
            if (saveSmsPreferences(view)) message("Alert settings saved.");
        });
        view.findViewById(R.id.skipSmsButton).setOnClickListener(v -> host().showInventory());
        refreshSmsState();
    }

    private boolean saveSmsPreferences(View view) {
        String phone = value(view, R.id.smsPhone).replaceAll("[\\s()\\-]", "");
        boolean enabled = ((com.google.android.material.switchmaterial.SwitchMaterial)
                view.findViewById(R.id.smsOptIn)).isChecked();
        if ((!phone.isEmpty() || enabled) && !phone.matches("\\+?[0-9]{7,15}")) {
            ((EditText) view.findViewById(R.id.smsPhone)).setError("Enter 7–15 digits, optionally starting with + and country code.");
            return false;
        }
        try { database().saveSms(host().userId(), phone, enabled); return true; }
        catch (android.database.SQLException exception) { message("Unable to save alert settings."); return false; }
    }

    public void refreshSmsState() {
        View view = getView();
        if (view == null || !"notifications".equals(screen)) return;
        TextView title = view.findViewById(R.id.smsStatusTitle);
        TextView body = view.findViewById(R.id.smsStatusBody);
        MaterialButton enable = view.findViewById(R.id.enableSmsButton);
        MaterialButton skip = view.findViewById(R.id.skipSmsButton);
        boolean granted = host().hasSmsPermission();
        boolean requested = host().hasRequestedSms();
        title.setText(granted ? R.string.sms_granted_title
                : requested ? R.string.sms_denied_title : R.string.sms_initial_title);
        body.setText(granted ? R.string.sms_granted_body
                : requested ? R.string.sms_denied_body : R.string.sms_initial_body);
        enable.setText(granted ? R.string.sms_open_settings : R.string.sms_enable);
        skip.setText(granted ? R.string.back_to_inventory : R.string.continue_without);
        if (!requireContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            body.setText(R.string.sms_unsupported);
            enable.setEnabled(false);
        }
    }
}

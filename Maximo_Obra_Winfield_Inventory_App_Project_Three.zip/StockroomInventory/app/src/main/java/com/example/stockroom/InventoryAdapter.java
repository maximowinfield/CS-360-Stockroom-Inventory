package com.example.stockroom;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemHolder> {
    private final List<InventoryItem> visibleItems = new ArrayList<>();
    private final List<InventoryItem> items;
    private final IntConsumer onDetails;
    private final IntConsumer onDelete;

    public InventoryAdapter(List<InventoryItem> items, IntConsumer onDetails, IntConsumer onDelete) {
        this.items = items;
        this.onDetails = onDetails;
        this.onDelete = onDelete;
        filter("", false);
    }

    public void filter(String query, boolean outOfStockOnly) {
        visibleItems.clear();
        String normalized = query.trim().toLowerCase(Locale.ROOT);
        for (InventoryItem item : items) {
            if ((!outOfStockOnly || item.quantity == 0)
                    && (item.name.toLowerCase(Locale.ROOT).contains(normalized)
                    || item.sku.toLowerCase(Locale.ROOT).contains(normalized))) {
                visibleItems.add(item);
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ItemHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
        InventoryItem item = visibleItems.get(position);
        holder.name.setText(item.name);
        holder.sku.setText(item.sku);
        holder.location.setText(holder.itemView.getContext()
                .getString(R.string.location_format, item.location));
        holder.quantity.setText(String.valueOf(item.quantity));
        boolean empty = item.quantity == 0;
        holder.status.setText(empty ? R.string.out_of_stock : R.string.in_stock);
        holder.status.setTextColor(ContextCompat.getColor(holder.itemView.getContext(),
                empty ? R.color.warning : R.color.primary));
        holder.status.setBackgroundResource(empty ? R.drawable.bg_warning : R.drawable.bg_status);
        holder.details.setContentDescription(holder.itemView.getContext()
                .getString(R.string.open_item_description, item.name));
        holder.delete.setContentDescription(holder.itemView.getContext()
                .getString(R.string.delete_item_description, item.name));
        holder.details.setOnClickListener(v -> onDetails.accept(item.id));
        holder.delete.setOnClickListener(v -> onDelete.accept(item.id));
    }

    @Override
    public int getItemCount() { return visibleItems.size(); }

    static class ItemHolder extends RecyclerView.ViewHolder {
        final TextView name, sku, location, quantity, status;
        final View details, delete;
        ItemHolder(View view) {
            super(view);
            name = view.findViewById(R.id.itemName);
            sku = view.findViewById(R.id.itemSku);
            location = view.findViewById(R.id.itemLocation);
            quantity = view.findViewById(R.id.itemQuantity);
            status = view.findViewById(R.id.itemStatus);
            details = view.findViewById(R.id.itemDetails);
            delete = view.findViewById(R.id.itemDelete);
        }
    }
}

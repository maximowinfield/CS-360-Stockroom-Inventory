package com.example.stockroom;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Reports modem submission results without claiming delivery to the recipient. */
public final class SmsResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!"com.example.stockroom.SMS_SENT".equals(intent.getAction())) return;
        Toast.makeText(context, getResultCode() == Activity.RESULT_OK
                ? R.string.sms_sent : R.string.sms_failed, Toast.LENGTH_LONG).show();
    }
}

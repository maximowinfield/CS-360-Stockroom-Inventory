package com.example.stockroom;

/** Immutable snapshot of one persisted inventory row. */
public final class InventoryItem {
    public final int id;
    public final String name, sku, location;
    public final int quantity;
    public InventoryItem(int id, String name, String sku, String location, int quantity) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }
}

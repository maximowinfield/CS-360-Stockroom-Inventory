package com.example.stockroom;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/** Hosts authenticated inventory screens and the optional SMS permission flow. */
public class MainActivity extends AppCompatActivity {
    private long userId = -1;
    public long userId() { return userId; }
    public InventoryDatabase database() { return InventoryDatabase.get(this); }
    public void signIn(long id) { userId = id; showInventory(); }

    private final ActivityResultLauncher<String> smsPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> refreshSmsScreen());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) userId = savedInstanceState.getLong("userId", -1);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });
        if (savedInstanceState == null) {
            showScreen("login", 0, false);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        state.putLong("userId", userId);
        super.onSaveInstanceState(state);
    }

    public void showScreen(String screen, int item, boolean addToBackStack) {
        if (!"login".equals(screen) && userId < 0) screen = "login";
        androidx.fragment.app.FragmentTransaction transaction = getSupportFragmentManager()
                .beginTransaction().setReorderingAllowed(true)
                .setCustomAnimations(R.anim.enter_screen, R.anim.exit_screen,
                        R.anim.enter_screen, R.anim.exit_screen)
                .replace(R.id.screenContainer, ScreenFragment.create(screen, item));
        if (addToBackStack) transaction.addToBackStack(screen);
        transaction.commit();
    }

    public void showInventory() {
        getSupportFragmentManager().popBackStackImmediate(null,
                FragmentManager.POP_BACK_STACK_INCLUSIVE);
        showScreen("inventory", 0, false);
    }

    public void logOut() {
        userId = -1;
        getSupportFragmentManager().popBackStackImmediate(null,
                FragmentManager.POP_BACK_STACK_INCLUSIVE);
        showScreen("login", 0, false);
    }

    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public boolean hasRequestedSms() {
        return getPreferences(MODE_PRIVATE).getBoolean("smsRequested", false);
    }

    public void requestSmsPermission() {
        // Runtime grant and account opt-in are both required before sending alerts.
        if (hasSmsPermission()) {
            openAppSettings();
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.sms_rationale_title)
                    .setMessage(R.string.sms_rationale_body)
                    .setNegativeButton(R.string.continue_without, (dialog, which) -> refreshSmsScreen())
                    .setPositiveButton(R.string.sms_enable, (dialog, which) -> launchSmsRequest())
                    .show();
        } else if (hasRequestedSms()) {
            // Android may stop showing the dialog after repeated denial.
            openAppSettings();
        } else {
            launchSmsRequest();
        }
    }

    private void launchSmsRequest() {
        getPreferences(MODE_PRIVATE).edit().putBoolean("smsRequested", true).apply();
        smsPermission.launch(Manifest.permission.SEND_SMS);
    }

    private void openAppSettings() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshSmsScreen();
    }

    private void refreshSmsScreen() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.screenContainer);
        if (fragment instanceof ScreenFragment) {
            ((ScreenFragment) fragment).refreshSmsState();
        }
    }
}

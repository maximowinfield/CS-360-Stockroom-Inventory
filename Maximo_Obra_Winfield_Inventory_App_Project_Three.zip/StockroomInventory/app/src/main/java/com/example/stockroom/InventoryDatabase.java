package com.example.stockroom;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One device-local stockroom shared by authenticated accounts. Starts with empty tables. */
public final class InventoryDatabase extends SQLiteOpenHelper {
    private static volatile InventoryDatabase instance;
    public static synchronized InventoryDatabase get(Context context) {
        if (instance == null) instance = new InventoryDatabase(context.getApplicationContext());
        return instance;
    }
    private InventoryDatabase(Context context) { super(context, "stockroom.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT NOT NULL UNIQUE, salt BLOB NOT NULL, password_hash BLOB NOT NULL, "
                + "phone TEXT NOT NULL DEFAULT '', sms_enabled INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE items (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "name TEXT NOT NULL, sku TEXT NOT NULL COLLATE NOCASE UNIQUE, "
                + "location TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future versions must use explicit, nondestructive migrations.
        throw new IllegalStateException("Database migration required");
    }
    private String normalize(String username) { return username.trim().toLowerCase(Locale.ROOT); }
    public long createUser(String username, char[] password) {
        byte[] salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put("username", normalize(username));
        values.put("salt", salt);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        return getWritableDatabase().insertOrThrow("users", null, values);
    }
    public long authenticate(String username, char[] password) {
        try (Cursor cursor = getReadableDatabase().query("users",
                new String[]{"_id", "salt", "password_hash"}, "username=?",
                new String[]{normalize(username)}, null, null, null)) {
            if (cursor.moveToFirst() && PasswordHasher.verify(password, cursor.getBlob(1), cursor.getBlob(2)))
                return cursor.getLong(0);
            return -1;
        }
    }
    public List<InventoryItem> items() {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("items", null, null, null,
                null, null, "name COLLATE NOCASE, _id")) {
            while (cursor.moveToNext()) items.add(readItem(cursor));
        }
        return items;
    }
    public InventoryItem item(int id) {
        try (Cursor cursor = getReadableDatabase().query("items", null, "_id=?",
                new String[]{String.valueOf(id)}, null, null, null)) {
            return cursor.moveToFirst() ? readItem(cursor) : null;
        }
    }
    private InventoryItem readItem(Cursor cursor) {
        return new InventoryItem(cursor.getInt(cursor.getColumnIndexOrThrow("_id")),
                cursor.getString(cursor.getColumnIndexOrThrow("name")),
                cursor.getString(cursor.getColumnIndexOrThrow("sku")),
                cursor.getString(cursor.getColumnIndexOrThrow("location")),
                cursor.getInt(cursor.getColumnIndexOrThrow("quantity")));
    }
    public int saveItem(int id, String name, String sku, String location, int quantity) {
        if (name.trim().isEmpty() || sku.trim().isEmpty() || location.trim().isEmpty() || quantity < 0)
            throw new IllegalArgumentException("Complete all fields; quantity must be zero or greater.");
        ContentValues values = new ContentValues();
        values.put("name", name.trim()); values.put("sku", sku.trim());
        values.put("location", location.trim()); values.put("quantity", quantity);
        if (id == 0) return (int) getWritableDatabase().insertOrThrow("items", null, values);
        if (getWritableDatabase().update("items", values, "_id=?",
                new String[]{String.valueOf(id)}) != 1) throw new IllegalStateException("Item no longer exists.");
        return id;
    }
    public void deleteItem(int id) {
        getWritableDatabase().delete("items", "_id=?", new String[]{String.valueOf(id)});
    }
    public void saveSms(long userId, String phone, boolean enabled) {
        ContentValues values = new ContentValues();
        values.put("phone", phone); values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update("users", values, "_id=?", new String[]{String.valueOf(userId)});
    }
    public String smsPhone(long userId, boolean onlyEnabled) {
        try (Cursor cursor = getReadableDatabase().query("users", new String[]{"phone", "sms_enabled"},
                "_id=?", new String[]{String.valueOf(userId)}, null, null, null)) {
            return cursor.moveToFirst() && (!onlyEnabled || cursor.getInt(1) == 1) ? cursor.getString(0) : "";
        }
    }
}

package com.example.stockroom;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Salted password derivation; passwords themselves never enter the database. */
public final class PasswordHasher {
    private PasswordHasher() { }
    public static byte[] newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }
    public static byte[] hash(char[] password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, 600000, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Password protection unavailable", exception);
        } finally {
            spec.clearPassword();
        }
    }
    public static boolean verify(char[] password, byte[] salt, byte[] expected) {
        return MessageDigest.isEqual(hash(password, salt), expected);
    }
}

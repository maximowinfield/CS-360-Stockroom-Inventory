package com.example.stockroom;

import static org.junit.Assert.*;
import android.content.Context;
import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Run on a disposable emulator. No test calls the SMS transport. */
@RunWith(AndroidJUnit4.class)
public class InventoryDatabaseTest {
    @Test public void accountsCrudAndPersistence() {
        Context context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        InventoryDatabase db = InventoryDatabase.get(context);
        String suffix = String.valueOf(System.nanoTime());
        String username = "test" + suffix;
        char[] password = "StockroomTest123!".toCharArray();
        long user = db.createUser(username, password);
        int id = 0;
        try {
            assertEquals(user, db.authenticate(username.toUpperCase(java.util.Locale.ROOT), password));
            assertEquals(-1, db.authenticate(username, "incorrect".toCharArray()));
            try { db.createUser(username, password); fail("Duplicate username accepted"); }
            catch (SQLiteConstraintException expected) { }
            id = db.saveItem(0, "Test box", suffix, "A-01", 2);
            assertEquals(2, db.item(id).quantity);
            try { db.saveItem(0, "Duplicate", suffix, "A-02", 1); fail("Duplicate SKU accepted"); }
            catch (SQLiteConstraintException expected) { }
            InventoryItem before = db.item(id);
            db.saveItem(id, "Renamed box", suffix, "B-02", 0);
            assertTrue(SmsAlerts.shouldAlert(before, db.item(id)));
            assertFalse(SmsAlerts.shouldAlert(db.item(id), db.item(id)));
            assertTrue(SmsAlerts.shouldAlert(null, db.item(id)));
            db.saveSms(user, "+12025550123", true);
            db.close(); // Reopen the on-disk database, not a cached list.
            assertEquals("Renamed box", db.item(id).name);
            assertEquals("B-02", db.item(id).location);
            assertEquals(0, db.item(id).quantity);
            assertEquals(user, db.authenticate(username, password));
            assertEquals("+12025550123", db.smsPhone(user, true));
            db.saveSms(user, "+12025550123", false);
            assertEquals("", db.smsPhone(user, true));
            db.deleteItem(id);
            assertNull(db.item(id));
        } finally {
            if (id > 0) db.deleteItem(id);
            db.getWritableDatabase().delete("users", "_id=?", new String[]{String.valueOf(user)});
            java.util.Arrays.fill(password, '\0');
        }
    }
}

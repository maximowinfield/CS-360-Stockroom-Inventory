STOCKROOM — CS 360 PROJECT THREE
Maximo Obra Winfield | Inventory option

OPEN AND BUILD
Extract the ZIP, then open the StockroomInventory folder in Android Studio.
Keep the Project Two toolchain: Android Gradle Plugin 9.4.0, Gradle 9.6.0,
JDK 25 daemon configuration, compile/target SDK 37, minimum SDK 34.
Allow Gradle sync and install missing SDK components when prompted.
Build debug APK: gradlew.bat :app:assembleDebug (Windows).
APK output: app/build/outputs/apk/debug/app-debug.apk.
Run database instrumentation checks: gradlew.bat :app:connectedDebugAndroidTest.
Use a disposable emulator with no production data for tests.

IMPLEMENTED
- Create an account from the login screen using its username/password fields.
  Usernames are trimmed and case-insensitive; passwords are case-sensitive,
  8–128 characters for registration. No default account is included.
- SQLite users and items tables start empty. All accounts share ONE device's
  stockroom, matching the original UI. This is not a cloud or multi-device app.
- Salted PBKDF2-HMAC-SHA256 (600,000 iterations); raw passwords are not saved.
  Password hashing runs on a background thread.
- Create, read, update and delete inventory. Unique case-insensitive SKU,
  required fields, nonnegative quantities, overflow checks, deletion confirmation.
- Responsive RecyclerView grid, text search, out-of-stock filter, live counts.
- Optional, per-account mobile number and opt-in in SMS alerts. Save settings,
  then allow Android SMS permission. Both saved opt-in and runtime permission
  are required. Turning off the switch and saving disables alerts for this account.
- SMS triggers on creation at zero or a positive-to-zero quantity change.
  Editing an already-zero item or reopening a screen does not send another SMS.
  Alerts go only to the currently signed-in account's saved number.
- SMS failures do not undo saved inventory. Modem results are reported by a
  non-exported receiver. Carrier submission is not proof of recipient delivery.
- Rotation preserves the active session and screen. Logout clears navigation.
  A fresh app launch requires login; closing the app does not erase SQLite data.

VALIDATION STATUS
Java syntax/resource checks and standalone password checks were run in the
preparation environment. Android build, instrumentation tests and emulator UI
checks were NOT run successfully: no SDK/emulator was installed and the Gradle
wrapper download failed with "Network is unreachable". No APK is included.
Do not treat source review as proof of a working APK. Complete the checks below
in Android Studio before submission. No instructor feedback was supplied.

EMULATOR / DEVICE ACCEPTANCE CHECKLIST (record actual results)
[ ] Fresh install: create account, log out, reject bad password, accept correct
    password, reject duplicate username; Back after logout cannot reopen stock.
[ ] Add two items, search name/SKU, filter zero stock, check totals and empty grid.
[ ] Reject duplicate SKU, blank fields, negative and overflow quantities.
[ ] Edit name/location/SKU/quantity; use +/- and signed adjustment; cancel delete,
    then confirm delete. Check exact results in the grid and detail screen.
[ ] Force-stop/reopen, log in, and verify all saved items and SMS settings remain.
[ ] Rotate login/form/detail/alerts; test keyboard, landscape and enlarged text.
[ ] Deny SMS: create/edit/delete and persist items normally; zero stock sends no SMS.
[ ] Allow SMS, save a number YOU CONTROL, enable account alerts, reduce stock 1->0:
    verify outgoing SMS. Reopen/edit at zero: no duplicate. Restock then reduce
    to zero: another alert. A newly created zero-stock item also triggers once.
[ ] Save opt-in OFF with Android permission still granted: no SMS. Revoke Android
    permission: no SMS. Repeated denial routes to app settings without a crash.
[ ] Missing SIM/no service/tablet: inventory still saves; unavailable SMS is handled.
    For emulator outgoing SMS, use a supported emulator setup (for example a second
    emulator's console port as destination if supported). If no transport exists,
    validate delivery separately on a consenting physical device with an active SIM.
    Do not confuse Extended Controls incoming-SMS simulation with outgoing delivery.
[ ] Run connectedDebugAndroidTest; capture screenshots of actual Project Three
    behavior. The old sample-data screenshots were removed to prevent confusion.

LIMITATIONS / LAUNCH
No password recovery, cloud sync or export yet. Clearing app storage/uninstalling
removes the local stockroom; Android backup is disabled. Login is a local access
barrier, not enterprise identity management. Read the separate launch plan for
Google Play's restricted SEND_SMS policy and the planned public-release alternative.
